package dao.order;

/**
 * @author
 */
public class OrderDAO {
}
