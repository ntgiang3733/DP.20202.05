package dao.order;

/**
 * @author
 */
public class OrderItemDAO {
}
