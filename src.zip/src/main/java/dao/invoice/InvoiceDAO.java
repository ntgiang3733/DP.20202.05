package dao.invoice;

/**
 * @author
 */
public class InvoiceDAO {

}
