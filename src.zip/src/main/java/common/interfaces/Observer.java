package common.interfaces;

/**
 * @author
 */
public interface Observer {

    void update(Observable observable);

}
